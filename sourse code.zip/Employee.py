from tkinter import*       ## Import all classes and functions from tkinter
from tkinter import ttk
from tkcalendar import DateEntry  #add calander in the entry feild of DOJ and DOB
import mysql.connector
from tkinter import messagebox 
from Manager import Manager  


class Employee():
    
    def __init__(self,root,admin_window):   
        self.admin_window = admin_window
        self.root = root      # Assign the root window to an instance variable
        self.root.geometry('1530x790+0+0')  ## Set the size and position of the window
        self.root.title('Employee Management System') ## Set the title of the window
        
        #taking variable for each entry feild
        self.var_dept = StringVar()
        self.var_desig = StringVar()
        self.var_name = StringVar()
        self.var_mobaile = StringVar()
        self.var_doj = StringVar()
        self.var_email = StringVar()
        self.var_country = StringVar()
        self.var_city = StringVar()
        self.var_married = StringVar()
        self.var_dob = StringVar()
        self.var_id_type = StringVar()
        self.var_id = StringVar()
        self.var_gender = StringVar()
        self.var_salary = StringVar()
        
        self.var_list_search = StringVar()
        self.var_search = StringVar()


        #Create and place a title label at the top of the window
        lbl_title =Label(self.root,text='EMPLOYEE MANAGENENT SYSTEM',font=('times new roman',37,'bold'),fg='darkblue',bg='white')
        lbl_title.place(x=0,y=0,width=1530,height=50)

        # Create and place the main frame
        main_frame = Frame(self.root,bd=3,relief=RIDGE,bg='white')
        main_frame.place(x=10,y=51,width=1505,height=730)

        # Create and place the upper frame within the main frame
        upper_frame = LabelFrame(main_frame,bd=2,relief=RIDGE,bg='white',text='Employee Information',font=('times new roman',10,'bold'),fg='red')
        upper_frame.place(x=10,y=10,width=1480,height=270)

        # Create and place the label for the department entry
        lbl_dept = Label(upper_frame, text='Department:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_dept.grid(row=0,column=0,padx=2,sticky=W)

        # Create and place the dropdown list for selecting department
        dept_entry = ttk.Combobox(upper_frame, textvariable=self.var_dept, font=('arial', 12, 'bold'), width=20, state='readonly')
        dept_entry['value'] = ('Software Development','Quality Assurance(QA)','Sales and Marketing','Finance and Accounting','Network and Infrastructure','Data Science and Analytics','Cybersecurity')
        dept_entry.grid(row=0,column=1,padx=2,pady=10,sticky=W)   # Place the combobox next to the label

        # Create and place the label for the department entry
        lbl_designation = Label(upper_frame, text='Designation:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_designation.grid(row=1,column=0,padx=2,sticky=W)

        # Create and place the dropdown list for selecting department
        dept_designation  = ttk.Combobox(upper_frame, textvariable=self.var_desig, font=('arial', 12, 'bold'), width=20, state='readonly')
        dept_designation['value'] = ('Software Developer','Front-End Developer','Back-End Developer','QA Engineer','Software Tester','QA Analyst','Sales Executive','Digital Marketing Specialist','Marketing Coordinator','Financial Analyst','Accountant','Network Engineer','Cloud Engineer','Network Architect','Data Scientist','Data Analyst','Data Engineer','Cybersecurity Analyst','Security Engineer')
        dept_designation.grid(row=1,column=1,padx=2,pady=10,sticky=W) 

        # Create and place the label for the name entry
        lbl_name = Label(upper_frame, text='      Name:      ', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_name.grid(row=0,column=2,padx=2,pady=10,sticky=W)
        
        # Create and place the entry field for the name
        name_entry = ttk.Entry(upper_frame, textvariable=self.var_name,width=25,font=('arial', 12, 'bold'))
        name_entry.grid(row=0,column=3,padx=2,pady=10)

        # Create and place the label for the mobile number entry
        lbl_ph_no = Label(upper_frame, text='      Mobaile number:      ', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_ph_no.grid(row=0,column=4,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the mobile number
        ph_no_entry = ttk.Entry(upper_frame, textvariable=self.var_mobaile,width=20,font=('arial', 12, 'bold'))
        ph_no_entry.grid(row=0,column=5,padx=2,pady=10)

        # Create and place the label for the date of joining entry
        lbl_doj = Label(upper_frame, text='D.O.J:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_doj.grid(row=2,column=0,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the date of joining
        doj_entry= DateEntry(upper_frame, textvariable=self.var_doj,width=20,font=('arial', 12, 'bold'),date_pattern='y-mm-dd')
        doj_entry.grid(row=2,column=1,padx=2,pady=10)

        # Create and place the label for the email entry
        lbl_email = Label(upper_frame, text='      Email:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_email.grid(row=1,column=2,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the email
        email_entry = ttk.Entry(upper_frame, textvariable=self.var_email,width=25,font=('arial', 12, 'bold'))
        email_entry.grid(row=1,column=3,padx=2,pady=10)

        # Create and place the label for the country entry
        lbl_country = Label(upper_frame, text='      Country:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_country.grid(row=1,column=4,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the country
        country_entry = ttk.Entry(upper_frame, textvariable=self.var_country, width=20,font=('arial', 12, 'bold'))
        country_entry.grid(row=1,column=5,padx=2,pady=10)
        
        # Create and place the label for the gender entry
        lbl_gender = Label(upper_frame, text='Gender:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_gender.grid(row=3,column=0,padx=2,pady=10,sticky=W)

        # Create and place the dropdown list for selecting gender
        gender_entry = ttk.Combobox(upper_frame, textvariable=self.var_gender, font=('arial', 12, 'bold'), width=20, state='readonly')
        gender_entry['value'] = ('M','F','O')
        gender_entry.grid(row=3,column=1,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the date of birth
        lbl_dob = Label(upper_frame, text='      D.O.B:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_dob.grid(row=2,column=2,padx=2,pady=10,sticky=W)

        # Create and place the label for the date of birth entry
        dob_entry= DateEntry(upper_frame, textvariable=self.var_dob,width=23,font=('arial', 12, 'bold'),date_pattern='y-mm-dd')
        dob_entry.grid(row=2,column=3,padx=2,pady=10)

        # Create and place the entry field for the salary
        lbl_salary = Label(upper_frame, text='      Salary:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_salary.grid(row=3,column=2,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the salary
        salary_entry= ttk.Entry(upper_frame, textvariable=self.var_salary, width=25,font=('arial', 12, 'bold'))
        salary_entry.grid(row=3,column=3,padx=2,pady=10)

        # Create and place the label for the married status entry
        lbl_marred_status = Label(upper_frame, text='Married status:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_marred_status.grid(row=4,column=0,padx=2,pady=10,sticky=W)

        # Create and place the dropdown list for selecting married status
        marred_status_entry = ttk.Combobox(upper_frame, textvariable=self.var_married, font=('arial', 12, 'bold'), width=20, state='readonly')
        marred_status_entry['value'] = ('Married','Single')
        marred_status_entry.grid(row=4,column=1,padx=2,pady=10,sticky=W)

        # Create and place the label for the Manager id
        lbl_manager_id = Label(upper_frame,text='      Manager ID:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_manager_id.grid(row=4,column=2,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the Manager ID
        self.manager_id = IntVar()
        entry_manager_id= ttk.Entry(upper_frame, textvariable=self.manager_id, width=25,font=('arial', 12, 'bold'))
        entry_manager_id.grid(row=4,column=3,padx=2,pady=10)

        # Create and place the dropdown list for selecting ID proof
        combo_select_id = ttk.Combobox(upper_frame, textvariable=self.var_id_type, font=('arial', 12, 'bold'), width=20, state='readonly')
        combo_select_id['value'] = ('Select ID Proof','Votar Card','Adhar Card','PAN card','Driving License')
        combo_select_id.current(0)
        combo_select_id.grid(row=3,column=4,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the selected ID proof
        id_proof_entry= ttk.Entry(upper_frame, textvariable=self.var_id, width=20,font=('arial', 12, 'bold'))
        id_proof_entry.grid(row=3,column=5,padx=2,pady=10)

        # Create and place the label for the city entry
        lbl_city= Label(upper_frame, text='      City:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_city.grid(row=2,column=4,padx=2,pady=10,sticky=W)

        # Create and place the entry field for the city
        city_entry= ttk.Entry(upper_frame, textvariable=self.var_city, width=20,font=('arial', 12, 'bold'))
        city_entry.grid(row=2,column=5,padx=2,pady=10)

        # Create and place the btton frame
        button_frame = Frame(self.root,bd=2,relief=RIDGE,bg='white')
        button_frame.place(x=1050,y=270,width=370,height=40)

        btn_add = Button(button_frame,text='Save', command=self.add_data, font=('arial', 12, 'bold'),width=8,bg='blue',fg='white',cursor='hand2')
        btn_add.grid(row=0,column=0,padx=1,pady=1)

        btn_update = Button(button_frame,text='Update', command=self.update_data, font=('arial', 12, 'bold'),width=8,bg='blue',fg='white',cursor='hand2')
        btn_update.grid(row=0,column=1,padx=1,pady=1)

        btn_delete = Button(button_frame,text='Delete', command=self.delete_data, font=('arial', 12, 'bold'),width=8,bg='blue',fg='white',cursor='hand2')
        btn_delete.grid(row=0,column=2,padx=1,pady=1)

        btn_reset = Button(button_frame,text='Reset', command=self.reset_data, font=('arial', 12, 'bold'),width=8,bg='blue',fg='white',cursor='hand2')
        btn_reset.grid(row=0,column=3,padx=1,pady=1)
        
        # Botton for go the manager portal
        btn_for_manager = Button(upper_frame,text='Go to Manager Portal', command=self.open_manager_page, font=('arial', 12, 'bold'),width=20,bg='purple',fg='blue',cursor='hand2')
        btn_for_manager.place(x=1250,y=10)

        # Create and place the lower frame within the main frame
        lower_frame = LabelFrame(main_frame,bd=2,relief=RIDGE,bg='white',text='Employee Information Table',font=('times new roman',10,'bold'),fg='darkblue')
        lower_frame.place(x=10,y=280,width=1480,height=435)

        #Create and place the scarch frame within the lower frame
        search_frame = LabelFrame(lower_frame,bd=2,relief=RIDGE,bg='white',text='Search Employee Information',font=('times new roman',10,'bold'),fg='brown')
        search_frame.place(x=5,y=0,width=1465,height=60)

        # Create and place the label for 'Search By'
        search_by =Label(search_frame,font=('arial', 12, 'bold'),text='Search By',fg='white',bg='green')
        search_by.grid(row=0,column=0,sticky=W,padx=5)

        # Create and place the dropdown list for selecting the search criteria
        com_txt_search = ttk.Combobox(search_frame, textvariable=self.var_list_search,state='readonly',font=('arial', 12, 'bold'),width=20)
        com_txt_search['value'] = ('Search By','Emp_ID','Manager_ID','Department', 'Designation','Mobile_Number','ID_Proof','Name','Email','Country','City','Married_Status','Gender')
        com_txt_search.current(0)
        com_txt_search.grid(row=0,column=1,padx=5,sticky=W)

        # Create and place the entry field for entering search text
        txt_search=ttk.Entry(search_frame, textvariable=self.var_search, width=22, font=("arial", 11, "bold"))
        txt_search.grid(row=0,column=2,padx=5)

        # Create and place the 'Search' button
        btn_search=Button(search_frame, text="Search", command=self.search_data,font=("arial", 11, "bold"), width=14,bg='blue',fg='white',cursor='hand2')
        btn_search.grid(row=0,column=3,padx=5)

        # Create and place the 'Show All' button
        btn_ShowAll=Button(search_frame, text="Show All",command=self.get_data, font=("arial", 11, "bold"), width=14,bg='blue',fg='white',cursor='hand2')
        btn_ShowAll.grid(row=0,column=4,padx=5)

        # Login button to trigger the logout action
        btn_logout = Button(self.root, text='Log Out', command=self.logout, font=('arial', 12, 'bold'), bg='red', fg='white', cursor='hand2')
        btn_logout.place(x=1350, y=10, width=100, height=30)
        

        #===============Employee Table================
        # Create and place the table frame within the lower frame
        table_frame=Frame(lower_frame,bd = 3,relief=RIDGE) 
        table_frame.place(x = 0 , y = 60, width=1470,height=350)

        # Create and place scrollbars for the table
        scroll_x = ttk.Scrollbar(table_frame, orient=HORIZONTAL) 
        scroll_y = ttk.Scrollbar(table_frame,orient=VERTICAL)
 
        # Create the employee table with defined columns and set the scroll commands
        self.employee_table=ttk.Treeview(table_frame,column=("Emp_ID","Manager_ID","Department","Designation","Name","Mobaile number","DOJ","Email","Country","City","Married Status","DOB","ID Type","ID Proof","Gender","Salary","Password"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        # Pack scrollbars into the table frame
        scroll_x.pack(side=BOTTOM, fill=X) 
        scroll_y.pack(side=RIGHT, fill=Y)

        # Configure scrollbars to work with the employee table
        scroll_x.config(command=self.employee_table.xview)
        scroll_y.config(command=self.employee_table.yview)
        
        # Define the column headers for the employee table
        self.employee_table.heading('Emp_ID',text='Emp_ID')
        self.employee_table.heading('Manager_ID',text='Manager_ID')
        self.employee_table.heading('Department',text='Department')
        self.employee_table.heading('Designation',text='Designation')
        self.employee_table.heading('Name',text='Name')
        self.employee_table.heading('Mobaile number',text='Mobaile number')
        self.employee_table.heading('DOJ',text='D.O.J')
        self.employee_table.heading('Email',text='Email')
        self.employee_table.heading('Country',text='Country')
        self.employee_table.heading('City',text='City')
        self.employee_table.heading('Married Status',text='Married Status')
        self.employee_table.heading('DOB',text='D.O.B')
        self.employee_table.heading('ID Type',text='ID Type')
        self.employee_table.heading('ID Proof',text='ID Proof')
        self.employee_table.heading('Gender',text='Gender')
        self.employee_table.heading('Salary',text='Salary')
        self.employee_table.heading('Password',text='Password')

        # Set the table to display only the defined headings
        self.employee_table['show']='headings'

        # Define the width of each column
        self.employee_table.column("Emp_ID", width=80)
        self.employee_table.column("Manager_ID", width=80)
        self.employee_table.column("Department", width=150)
        self.employee_table.column("Designation", width=150)
        self.employee_table.column("Name", width=150)
        self.employee_table.column("Mobaile number", width=100)
        self.employee_table.column("DOJ", width=70)
        self.employee_table.column("Email", width=180)
        self.employee_table.column("Country", width=100)
        self.employee_table.column("City", width=100)
        self.employee_table.column("Married Status", width=75)
        self.employee_table.column("DOB", width=70)
        self.employee_table.column("ID Type", width=80)
        self.employee_table.column("ID Proof", width=100)
        self.employee_table.column("Gender", width=60)
        self.employee_table.column("Salary", width=100)
        self.employee_table.column("Password", width=100)

        # Pack the table to fill both X and Y axes and expand within the frame
        self.employee_table.pack(fill=BOTH, expand=1)

        self.employee_table.bind("<ButtonRelease>",self.get_cursor)

        self.get_data()
      
      #----------------------function declearation--------------------------

    def add_data(self):
        if self.var_dept.get() == "" or self.var_desig.get()=="" or self.var_name.get() == "" or self.var_mobaile.get()=="" or self.var_doj.get()=="" or self.var_email.get() == "" or self.var_country.get()=="" or self.var_city.get()=="" or self.var_id_type.get()=="" or self.var_id.get()=="" or self.var_gender.get()=="" or self.manager_id.get()=="":
            messagebox.showerror('Error', 'All Fields are required')
        else:
          try:
              conn = mysql.connector.connect(
                  host='localhost',
                  username='root',
                  password='Rahul@2012',
                  database='employee_management_system'
              )
              my_cursor = conn.cursor()
              my_cursor.execute('insert into employee (Manager_ID, Department, Designation, Name, Mobile_Number, DOJ, Email, Country, City, Married_Status, DOB, ID_Type, ID_Proof, Gender, Salary) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)',
                  (
                      self.manager_id.get(),
                      self.var_dept.get(),
                      self.var_desig.get(),
                      self.var_name.get(),
                      self.var_mobaile.get(),
                      self.var_doj.get(),
                      self.var_email.get(),
                      self.var_country.get(),
                      self.var_city.get(),
                      self.var_married.get(),
                      self.var_dob.get(),
                      self.var_id_type.get(),
                      self.var_id.get(),
                      self.var_gender.get(),
                      self.var_salary.get()
                  )
              )
              conn.commit()
              self.get_data()  #To imedietly show the data in table
              conn.close()
              messagebox.showinfo('Success', 'Employee has been added!', parent=self.root)
          except Exception as es:
              messagebox.showerror('Error', f'Due to {str(es)}', parent=self.root)


    # get data from mysql
    def get_data(self):
        conn = mysql.connector.connect(
                    host='localhost',
                    username='root',
                    password='Rahul@2012',
                    database='employee_management_system'
                )
        my_cursor = conn.cursor()
        my_cursor.execute('select * from employee')
        data=my_cursor.fetchall()
        if len(data)!=0:
            self.employee_table.delete(*self.employee_table.get_children())
            for i in data:
                self.employee_table.insert("", END, values=i)
            conn.commit()
        conn.close()

    def get_cursor(self, event=""):
        cursor_row=self.employee_table.focus()
        content=self.employee_table.item(cursor_row)
        data=content['values']

        self.manager_id.set(data[1])
        self.var_dept.set(data[2])
        self.var_desig.set(data[3])
        self.var_name.set(data[4])
        self.var_mobaile.set(data[5])
        self.var_doj.set(data[6])
        self.var_email.set(data[7])
        self.var_country.set(data[8])
        self.var_city.set(data[9])
        self.var_married.set(data[10])
        self.var_dob.set(data[11])
        self.var_id_type.set(data[12])
        self.var_id.set(data[13])
        self.var_gender.set(data[14])
        self.var_salary.set(data[15])
        

    def update_data(self):
    # Check if mandatory fields are empty
        if self.var_dept.get() == "" or self.var_desig.get()=="" or self.var_name.get() == "" or self.var_mobaile.get()=="" or self.var_doj.get()=="" or self.var_email.get() == "" or self.var_country.get()=="" or self.var_city.get()=="" or self.var_id_type.get()=="" or self.var_id.get()=="" or self.var_gender.get()=="" or self.manager_id.get()=="":
            messagebox.showerror('Error', 'All Fields are required')
        else:
            try:
                # Ask for confirmation before updating the data
                update = messagebox.askyesno('Update', 'Are you sure you want to update this employee data?')
                if update:
                    # Establish a connection to the database
                    conn = mysql.connector.connect(
                        host='localhost',
                        username='root',
                        password='Rahul@2012',
                        database='employee_management_system'
                    )
                    my_cursor = conn.cursor()

                    # Corrected SQL query with proper syntax and placeholders
                    my_cursor.execute('''
                        UPDATE employee 
                        SET Manager_ID=%s,Department=%s,Designation=%s, Name=%s, Mobile_Number=%s, DOJ=%s, Email=%s, 
                            Country=%s, City=%s, Married_Status=%s, DOB=%s, 
                            ID_Type=%s, Gender=%s, Salary=%s 
                        WHERE ID_Proof=%s
                    ''', (
                        self.manager_id.get(),
                        self.var_dept.get(),
                        self.var_desig.get(),
                        self.var_name.get(),
                        self.var_mobaile.get(),
                        self.var_doj.get(),
                        self.var_email.get(),
                        self.var_country.get(),
                        self.var_city.get(),
                        self.var_married.get(),
                        self.var_dob.get(),
                        self.var_id_type.get(),
                        self.var_gender.get(),
                        self.var_salary.get(),
                        self.var_id.get()
                    ))

                    conn.commit()  # Save the changes
                    self.get_data()  # To immediately show the updated data in the table
                    conn.close()  # Close the database connection
                    messagebox.showinfo('Success', 'Employee successfully updated!', parent=self.root)
                else:
                    if not update:
                        return
            except Exception as es:
                messagebox.showerror('Error', f'Due to {str(es)}', parent=self.root)
       
    def delete_data(self):
        try:
             # Ask for confirmation before deleting
            Delete = messagebox.askyesno("Delete", 'Are you sure you want to delete this employee?')
            if Delete:
               # Establish the connection to the database
              conn = mysql.connector.connect(
                   host='localhost',
                  username='root',
                   password='Rahul@2012',
                   database='employee_management_system'
               )
              my_cursor = conn.cursor()
               # SQL query to delete an employee based on the ID proof
              sql = 'DELETE FROM employee WHERE ID_Proof = %s'
               # Corrected 'get()' instead of 'grt()' to fetch the value
              value = (self.var_id.get(),)
              # Execute the query
              my_cursor.execute(sql, value)
              conn.commit()
               # Refresh data in the application after deletion
              self.get_data()
              conn.close()
               # Display success message
              messagebox.showinfo('Success', 'Employee deleted successfully!', parent=self.root)
            else:
                 if not Delete:
                     return
        except Exception as es:
          # Show error message if something goes wrong
          messagebox.showerror('Error', f'Due to {str(es)}', parent=self.root)

    def reset_data(self):
        self.var_dept.set("")
        self.var_desig.set("")
        self.var_name.set("")
        self.var_mobaile.set("")
        self.var_doj.set("")
        self.var_email.set("")
        self.var_country.set("")
        self.var_city.set("")
        self.var_married.set("")
        self.var_dob.set("")
        self.var_id_type.set("Select ID Proof")
        self.var_id.set("")
        self.var_gender.set("")
        self.var_salary.set("")
        self.manager_id.set("0")

    def search_data(self):
    # Check if search fields are empty
        if self.var_list_search.get() == '' or self.var_search.get() == '':
            messagebox.showerror('Error', 'Please select any option')
        else:
            try:
                # Establish connection to the database
                conn = mysql.connector.connect(
                host='localhost',
                username='root',
                password='Rahul@2012',
                database='employee_management_system')
                my_cursor = conn.cursor()
                # Use parameterized query to avoid SQL injection
                sql = f"SELECT * FROM employee WHERE {self.var_list_search.get()} LIKE %s"
                value = ('%' + self.var_search.get() + '%',)
                my_cursor.execute(sql, value)

                # Fetch all matching rows
                rows = my_cursor.fetchall()

                # Check if any rows are returned
                if len(rows) != 0:
                    # Clear the table before inserting new results
                    self.employee_table.delete(*self.employee_table.get_children())
                    # Insert each row into the table
                    for row in rows:
                        self.employee_table.insert("", END, values=row)
                    conn.commit()
                    conn.close()  # Corrected method call to close the connection
                else:
                    # Show message if no matches are found
                    messagebox.showinfo('No Match', 'No match found!')
            except Exception as es:
                # Show error message if something goes wrong
                messagebox.showerror('Error', f'Due to {str(es)}', parent=self.root)

    
    def open_manager_page(self):
        # Create a new window for the employee page
        self.new_window = Toplevel(self.root)
        self.app = Manager(self.new_window)

    def logout(self):
        self.root.destroy()  # Close the signup window
        self.admin_window.deiconify()  # Show the login window again


              
           










#Window
if __name__=="__main__":
    root = Tk()
    obj = Employee(root)
    root.mainloop()