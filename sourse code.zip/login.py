from tkinter import *
from tkinter import ttk
from tkinter import messagebox # Import messagebox to show dialog windows
import mysql.connector          # Import MySQL connector to interact with MySQL databases
from Emp_Profile import EmployeeDashboard # Import the employee dashboard module
from Employee import Employee  # Import the Employee class or module
from signup import SignupPage  # Import the signup page module
from Manager_profile import ManagerDashboard # Import the manager dashboard module

# Class definition for the Login Page
class LoginPage:
    def __init__(self, root):
         # Set up the root window (parent window)
        self.root = root
        self.root.geometry('1540x830+0+0') # Set the window size and position
        self.root.title('Employee Management System') # Set the window title

        # Create and place a label for the title
        lbl_title = Label(self.root, text='Wellcome to Employee Management System', font=('times new roman', 25, 'bold'), fg='darkblue', bg='lightblue')
        lbl_title.place(x=0, y=0, width=1530, height=50)
        
        # Create the main frame for the login section
        main_frame = Frame(self.root, bd=3, relief=RIDGE, bg='lightyellow')
        main_frame.place(x=575, y=180, width=370, height=400)

        # Create and place a label for the login header
        lbl_login = Label(main_frame, text='SIGNIN', font=('arial', 18, 'bold'), fg='green', bg='lightyellow')
        lbl_login.place(x=140, y=10)
  
        # Label for the 'Login as' prompt
        lbl_login_as = Label(main_frame, text='Login as:', font=('arial', 12, 'bold'), fg='gray', bg='lightyellow')
        lbl_login_as.place(x=50, y=60)

        # Create a dropdown menu for user type (Admin, Manager, Employee)
        self.user_type = StringVar(value="Admin") # Set the default value to "Admin"
        self.user_type_menu = OptionMenu(main_frame, self.user_type, "Admin", "Manager", "Employee",command=self.toggle_buttons)
        self.user_type_menu.place(x=50, y=90)

        # Label for username input
        lbl_username = Label(main_frame, text='UserName(Email):', font=('arial', 12, 'bold'), fg='gray', bg='lightyellow')
        lbl_username.place(x=50, y=130)

        # Entry field for the username
        self.username_entry = ttk.Entry(main_frame, width=30, font=('arial', 12))
        self.username_entry.place(x=50, y=160)
 
        # Label for password input
        lbl_password = Label(main_frame, text='Password:', font=('arial', 12, 'bold'), fg='gray', bg='lightyellow')
        lbl_password.place(x=50, y=200)

        # Entry field for the password with masked characters
        self.password_entry = ttk.Entry(main_frame, width=30, font=('arial', 12),show='*')
        self.password_entry.place(x=50, y=230)

        # Checkbox to show or hide the password
        show_password = Checkbutton(main_frame, command=self.show_password, text='Show Password',bg='lightyellow')
        show_password.place(x=50,y=255)

        # Login button to trigger the login action
        btn_login = Button(main_frame, text='LOGIN', command=self.login, font=('arial', 12, 'bold'), bg='lightpink', fg='blue')
        btn_login.place(x=135, y=290, width=100, height=30)

        # Forgot Password button (currently does nothing)
        self.forgot_btn = Button(main_frame, text='Forgot Password?', font=('arial', 10, 'bold'), bg='lightyellow', fg='orange', bd=0, cursor='hand2')
        self.forgot_btn.place(x=120, y=335)

        # Sign-up button to navigate to the signup page
        self.signup_btn = Button(main_frame, text="Don't have an account? Sign up", font=('arial', 10, 'bold'), bg='lightyellow',fg='brown', bd=0, cursor='hand2', command=self.open_signup_page)
        self.signup_btn.place(x=80, y=360)

    # Function to enable/disable 'Sign Up' buttons based on user type
    def toggle_buttons(self, selection):
        """Enable or disable 'Forgot Password' and 'Sign up' buttons based on selection."""
        if selection in ['Manager', 'Employee']: # Disable signup for Managers and Employees
            self.signup_btn.config(state=DISABLED)
        else: 
            self.signup_btn.config(state=NORMAL)  # Enable signup for Admins
    
    # Function to handle login action
    def login(self):
        # Check if the username or password fields are empty
        if self.username_entry.get() == '' or self.password_entry.get() == '':
            messagebox.showerror('Error', 'All fields are required!') # Show an error message
            return

        try:
            # Connect to the MySQL database
            conn = mysql.connector.connect(
                host='localhost',
                username='root',
                password='Rahul@2012',
                database='employee_management_system'
            )
            my_cursor = conn.cursor()
            # Get the selected user type (Admin, Manager, or Employee)
            user_type = self.user_type.get()
            table = ''  # Initialize table name
            # Determine the table based on user type
            if user_type == 'Admin':
                table = 'admin'
            elif user_type == 'Manager':
                table = 'manager'
            elif user_type == 'Employee':
                table = 'employee'
            
            # Prepare SQL query to check user credentials
            query = f"SELECT * FROM {table} WHERE Email = %s AND Password = %s"
            values = (self.username_entry.get(), self.password_entry.get())

            # Execute the query with provided credentials
            my_cursor.execute(query, values)
            row = my_cursor.fetchone() # Fetch one record

            # If a valid record is found
            if row:
                Emp_ID = row[0]  # employee ID is the first column
                Manager_ID = row[0]  # Manager ID is the first column 

                # Navigate to the corresponding dashboard based on user type
                if user_type == 'Employee': 
                    self.open_employee_profile(Emp_ID)  # Open employee dashboard
                elif user_type == 'Admin':  
                    self.open_admin_page() # Open admin dashboard
                elif user_type == 'Manager':
                    self.open_manager_profile(Manager_ID) # Open manager dashboard
            else:
                messagebox.showerror('Error', 'Invalid username or password') # Show error message

            conn.close() # Close the database connection

        except mysql.connector.Error as err:
            messagebox.showerror('Database Error', f"Error: {str(err)}")  # Handle database errors

     # Function to toggle the visibility of the password
    def show_password(self):
        if self.password_entry.cget('show') == '*':  # If password is masked
            self.password_entry.config(show='')     # Unmask the password
        else:
            self.password_entry.config(show='*')  # Mask the password again


    def open_employee_profile(self, Emp_ID):
        self.root.withdraw()  # Hides the login window
        # Create a new window for the employee dashboard
        self.employee_window = Toplevel(self.root)
        self.app = EmployeeDashboard(self.employee_window, Emp_ID,self.root)  # Pass the employee ID to the employee dashboard

    def open_manager_profile(self, Manager_ID):
        self.root.withdraw()  # Hides the login window
        # Create a new window for the Manager dashboard
        self.manager_window = Toplevel(self.root)
        self.app = ManagerDashboard(self.manager_window, Manager_ID,self.root)  # Pass the Manager ID to the manager dashboard

    def open_admin_page(self):
        self.root.withdraw()  # Hides the login window
        # Create a new window for the employee page
        self.admin_window = Toplevel(self.root)
        self.app = Employee(self.admin_window,self.root) # Load the employee class (as Admin page) in the new window

    def open_signup_page(self):
        self.root.withdraw()  # Hides the login window
        # Function to open the signup page, not the employee page
        self.signup_window = Toplevel(self.root)
        self.app = SignupPage(self.signup_window,self.root)  # Open the signup page by calling SignupPage class

    # #forgot password 
    # def forget_password(self):
    #     self.root2 = Toplevel()
    #     self.root2.title('Forget Password')
    #     self.root2.geometry("400x400+450+150")
    #     self.root2.config(bg='#FFEFD5')
    #     self.root2.focus_force()
    #     self.root2.grab_set()

    #     t = Label(self.root2, text="Forget Password", font=('times new roman',20,'bold'),fg='red',bg='#FFEFD5')
    #     t.place(x=90,y=10)

    #     lbl_user_type = Label(self.root2, text='User Type:', font=('arial', 12, 'bold'), fg='#000080', bg='#FFEFD5')
    #     lbl_user_type.place(x=50, y=60)

    #     self.user = StringVar(value="Admin")
    #     self.user_menu = OptionMenu(self.root2, self.user, "Admin", "Manager", "Employee")
    #     self.user_menu.place(x=50, y=90)

    #     # Create and place the label for the security question
    #     lbl_id_type = Label(self.root2, text='Select ID Type:', font=('arial', 12), fg='#000080', bg='#FFEFD5')
    #     lbl_id_type.place(x=50,y=130)

    #     # Create and place the dropdown list for selecting security question
    #     self.id_type = ttk.Combobox(self.root2, font=('arial', 12),state='readonly')
    #     self.id_type['value'] = ('Select ID Proof','Votar Card','Adhar Card','PAN card','Driving License')
    #     self.id_type.place(x=50,y=155,width=250)

    #      # Create and place the label for the security question
    #     lbl_id_proof = Label(self.root2, text='ID Number:', font=('arial', 12), fg='#000080', bg='#FFEFD5')
    #     lbl_id_proof.place(x=50,y=195)

    #     #Create and place the entry field for ths ecurity
    #     self.id_number = ttk.Entry(self.root2,font=('arial', 12))
    #     self.id_number.place(x=50,y=220,width=250)

    #     lbl_new_password = Label(self.root2, text='Set new Password:', font=('arial', 12), fg='#000080', bg='#FFEFD5')
    #     lbl_new_password.place(x=50, y=265)

    #     self.new_password_entry = ttk.Entry(self.root2, width=27, font=('arial', 12),show='*')
    #     self.new_password_entry.place(x=50, y=290)

    #     show_password_2 = Checkbutton(self.root2, command=self.show_password_2, text='Show Password',bg='#FFEFD5')
    #     show_password_2.place(x=50,y=315)

    #     btn_submit = Button(self.root2, text='SUBMIT',command=self.set_new_password, font=('arial', 12, 'bold'), bg='lightpink', fg='blue')
    #     btn_submit.place(x=145, y=350, width=100, height=30)

    # def show_password_2(self):
    #     if self.new_password_entry.cget('show') == '*':
    #         self.new_password_entry.config(show='')
    #     else:
    #         self.new_password_entry.config(show='*')

    # def set_new_password(self):
    #     if self.id_type.get() == '' or self.id_number.get() == '' or self.new_password_entry.get() == '':
    #         messagebox.showerror('Error', 'All fields are required!')
    #         return

    #     try:
    #         # Database connection
    #         conn = mysql.connector.connect(
    #             host='localhost',
    #             username='root',
    #             password='Rahul@2012',
    #             database='employee_management_system'
    #         )
    #         cursor = conn.cursor()

    #         user_type = self.user.get()
    #         table = ''
    #         id_field = 'ID_Proof'  # Use ID_Proof for all types if Admin doesn't have an ID column
        
    #         # Determine the correct table based on user_type
    #         if user_type == 'Admin':
    #             table = 'admin'
    #             id_field = 'ID_Proof'
    #         elif user_type == 'Manager':
    #             table = 'manager'
    #             id_field = 'Manager_ID'  # Unique identifier for Manager
    #         elif user_type == 'Employee':
    #             table = 'employee'
    #             id_field = 'Emp_ID'  # Unique identifier for Employee
    #         else:
    #             messagebox.showerror('Error', 'Invalid user type!')
    #             return

    #         # Fetch the user based on ID_Type and ID_Proof (or ID_Number)
    #         query = f"SELECT * FROM {table} WHERE ID_Type = %s AND ID_Proof = %s"
    #         values = (self.id_type.get(), self.id_number.get())
    #         cursor.execute(query, values)
    #         user_data = cursor.fetchone()

    #         if user_data:
    #             # Update the password for the matched user
    #             update_query = f"UPDATE {table} SET Password = %s WHERE {id_field} = %s"
    #             new_password = self.new_password_entry.get()  # Extract password from entry widget
    #             cursor.execute(update_query, (new_password, self.id_number.get()))
    #             conn.commit()

    #             messagebox.showinfo('Success', 'Password updated successfully!')
    #         else:
    #             messagebox.showerror('Error', 'Invalid ID type or ID proof!')

    #         conn.close()

    #     except mysql.connector.Error as err:
    #         messagebox.showerror('Database Error', f"Error: {str(err)}")


        



# Main Application Entry Point
if __name__ == "__main__":
    root = Tk()
    app = LoginPage(root)
    root.mainloop()


