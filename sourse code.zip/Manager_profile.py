from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import mysql.connector

class ManagerDashboard:
    def __init__(self, root, Manager_ID,manager_window):
        self.manager_window = manager_window
        self.root = root  # The root window for the Manager Dashboard
        self.Manager_ID = Manager_ID  # Store the Manager ID for later use
        self.root.title("Manager Dashboard")
        self.root.geometry("1530x850+0+0")

        #Create and place a title label at the top of the window
        lbl_title =Label(self.root,text='MANAGER DASHBOARD',font=('times new roman',37,'bold'),fg='darkblue',bg='white')
        lbl_title.place(x=0,y=0,width=1530,height=50)


        # Create and place the main frame
        main_frame = Frame(self.root,bd=3,relief=RIDGE,bg='white')
        main_frame.place(x=10,y=51,width=1505,height=770)

        # Create and place the upper frame within the main frame
        upper_frame = LabelFrame(main_frame,bd=2,relief=RIDGE,bg='white',text='Manager Information',font=('times new roman',10,'bold'),fg='magenta')
        upper_frame.place(x=10,y=10,width=1480,height=180)

        # Create and place the label for displaying manager details
        self.manager_details_label = Label(upper_frame, text='', font=('arial', 12, 'bold'), fg='blue', bg='white')
        self.manager_details_label.pack(pady=10)

        # Fetch and display manager details
        self.fetch_manager_details()
#================Emplloyee information table ================================
        # Create and place the upper frame within the Middle frame
        middle_frame = LabelFrame(main_frame,bd=2,relief=RIDGE,bg='white',text='Employee Information',font=('times new roman',10,'bold'),fg='magenta')
        middle_frame.place(x=10,y=195,width=1480,height=255)

        # Create and place scrollbars for the table
        scroll_x = ttk.Scrollbar(middle_frame, orient=HORIZONTAL) 
        scroll_y = ttk.Scrollbar(middle_frame,orient=VERTICAL)
 
        # Create the employee table with defined columns and set the scroll commands
        self.employee_table=ttk.Treeview(middle_frame,column=("Emp_ID","Manager_ID","Department","Designation","Name","Mobaile number","DOJ","Email","Country","City","Married Status","DOB","ID Type","ID Proof","Gender","Salary"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        # Pack scrollbars into the table frame
        scroll_x.pack(side=BOTTOM, fill=X) 
        scroll_y.pack(side=RIGHT, fill=Y)

        # Configure scrollbars to work with the employee table
        scroll_x.config(command=self.employee_table.xview)
        scroll_y.config(command=self.employee_table.yview)
        
        # Define the column headers for the employee table
        self.employee_table.heading('Emp_ID',text='Emp_ID')
        self.employee_table.heading('Manager_ID',text='Manager_ID')
        self.employee_table.heading('Department',text='Department')
        self.employee_table.heading('Designation',text='Designation')
        self.employee_table.heading('Name',text='Name')
        self.employee_table.heading('Mobaile number',text='Mobaile number')
        self.employee_table.heading('DOJ',text='D.O.J')
        self.employee_table.heading('Email',text='Email')
        self.employee_table.heading('Country',text='Country')
        self.employee_table.heading('City',text='City')
        self.employee_table.heading('Married Status',text='Married Status')
        self.employee_table.heading('DOB',text='D.O.B')
        self.employee_table.heading('ID Type',text='ID Type')
        self.employee_table.heading('ID Proof',text='ID Proof')
        self.employee_table.heading('Gender',text='Gender')
        self.employee_table.heading('Salary',text='Salary')

        # Set the table to display only the defined headings
        self.employee_table['show']='headings'

        # Define the width of each column
        self.employee_table.column("Emp_ID", width=80)
        self.employee_table.column("Manager_ID", width=80)
        self.employee_table.column("Department", width=180)
        self.employee_table.column("Designation", width=180)
        self.employee_table.column("Name", width=150)
        self.employee_table.column("Mobaile number", width=100)
        self.employee_table.column("DOJ", width=70)
        self.employee_table.column("Email", width=180)
        self.employee_table.column("Country", width=100)
        self.employee_table.column("City", width=100)
        self.employee_table.column("Married Status", width=90)
        self.employee_table.column("DOB", width=70)
        self.employee_table.column("ID Type", width=80)
        self.employee_table.column("ID Proof", width=100)
        self.employee_table.column("Gender", width=60)
        self.employee_table.column("Salary", width=100)

        # Pack the table to fill both X and Y axes and expand within the frame
        self.employee_table.pack(fill=BOTH, expand=1)
        self.fatch_employee_data()
#==========================Application History table=======================================
        # Create and place the upper frame within the lower frame
        lower_frame = LabelFrame(main_frame,bd=2,relief=RIDGE,bg='white',text='Application History',font=('times new roman',10,'bold'),fg='magenta')
        lower_frame.place(x=10,y=455,width=1480,height=255)

        # Create and place scrollbars for the table
        scroll_x = ttk.Scrollbar(lower_frame, orient=HORIZONTAL) 
        scroll_y = ttk.Scrollbar(lower_frame,orient=VERTICAL)
 
        # Create the employee table with defined columns and set the scroll commands
        self.application_table=ttk.Treeview(lower_frame,column=("Application_ID","Emp_ID","LeaveType","StartDate","EndDate","Reason","Status"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        # Pack scrollbars into the table frame
        scroll_x.pack(side=BOTTOM, fill=X) 
        scroll_y.pack(side=RIGHT, fill=Y)

        # Configure scrollbars to work with the employee table
        scroll_x.config(command=self.application_table.xview)
        scroll_y.config(command=self.application_table.yview)

        # Define the column headers for the employee table
        self.application_table.heading('Application_ID',text='Application_ID')
        self.application_table.heading('Emp_ID',text='Emp_ID')
        self.application_table.heading('LeaveType',text='LeaveType')
        self.application_table.heading('StartDate',text='StartDate')
        self.application_table.heading('EndDate',text='EndDate')
        self.application_table.heading('Reason',text='Reason')
        self.application_table.heading('Status',text='Status')

        # Set the table to display only the defined headings
        self.employee_table['show']='headings'

        # Define the width of each column
        self.application_table.column("Application_ID", width=100)
        self.application_table.column("Emp_ID", width=60)
        self.application_table.column("LeaveType", width=80)
        self.application_table.column("StartDate", width=80)
        self.application_table.column("EndDate", width=80)
        self.application_table.column("Reason", width=500)
        self.application_table.column("Status", width=80)

        # Pack the table to fill both X and Y axes and expand within the frame
        self.application_table.pack(fill=BOTH, expand=1)
        self.fatch_application_data()


         # Approve and Reject buttons
        approve_button = Button(main_frame, text="Approve", command=self.approve_application, font=('times new roman', 10, 'bold'), bg='green', fg='white')
        approve_button.place(x=630, y=725, width=100)

        reject_button = Button(main_frame, text="Reject", command=self.reject_application, font=('times new roman', 10, 'bold'), bg='red', fg='white')
        reject_button.place(x=730, y=725, width=100)

    # Login button to trigger the logout action
        btn_logout = Button(self.root, text='Log Out', command=self.logout, font=('arial', 12, 'bold'), bg='red', fg='white', cursor='hand2')
        btn_logout.place(x=1350, y=10, width=100, height=30)



#-----------------------------------------------------------------------------------------
    def fetch_manager_details(self):
        try:
            # Connect to MySQL database
            conn = mysql.connector.connect(
                host='localhost',
                username='root',
                password='Rahul@2012',
                database='employee_management_system'
            )
            my_cursor = conn.cursor()

            # Fetch employee details based on employee_id
            query = 'SELECT * FROM manager WHERE Manager_ID = %s'
            my_cursor.execute(query, (self.Manager_ID,))
            manager_data = my_cursor.fetchone()

            if manager_data:
                # Create and place labels and entries in the required layout using grid
                labels = [
                    ("Manager ID:", 0, 0), ("Department:", 1, 0), ("Email:", 2, 0), ("D.O.J:", 3, 0),
                    ("Name:", 0, 2), ("Mobile_Number:", 1, 2), ("Country:", 2, 2), ("City:", 3, 2), 
                    ("Married Status:", 0, 4), ("D.O.B:", 1, 4), ("ID Type:", 2, 4), ("ID Proof:", 3, 4),
                    ("Gender:", 0, 6), ("Salary:", 1, 6) ,("Password:", 2, 6)
                ]

                # Create labels and text boxes for displaying manager details
                for label_text, row, col in labels:
                    Label(self.manager_details_label, text=label_text, font=('arial', 12, 'bold'), fg='red', bg='white').grid(row=row, column=col, padx=10, pady=5, sticky=W)

                # Display data in corresponding positions
                Label(self.manager_details_label, text=manager_data[0], font=('arial', 12), bg = 'white', fg='green').grid(row=0, column=1, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[1], font=('arial', 12), bg = 'white', fg='green').grid(row=1, column=1, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[5], font=('arial', 12), bg = 'white', fg='green').grid(row=2, column=1, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[4], font=('arial', 12), bg = 'white', fg='green').grid(row=3, column=1, padx=10, pady=5, sticky=W)

                Label(self.manager_details_label, text=manager_data[2], font=('arial', 12), bg = 'white', fg='green').grid(row=0, column=3, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[3], font=('arial', 12), bg = 'white', fg='green').grid(row=1, column=3, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[6], font=('arial', 12), bg = 'white', fg='green').grid(row=2, column=3, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[7], font=('arial', 12), bg = 'white', fg='green').grid(row=3, column=3, padx=10, pady=5, sticky=W)

                Label(self.manager_details_label, text=manager_data[8], font=('arial', 12), bg = 'white', fg='green').grid(row=0, column=5, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[9], font=('arial', 12), bg = 'white', fg='green').grid(row=1, column=5, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[10], font=('arial', 12), bg = 'white', fg='green').grid(row=2, column=5, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[11], font=('arial', 12), bg = 'white', fg='green').grid(row=3, column=5, padx=10, pady=5, sticky=W)

                Label(self.manager_details_label, text=manager_data[12], font=('arial', 12), bg = 'white', fg='green').grid(row=0, column=7, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[13], font=('arial', 12), bg = 'white', fg='green').grid(row=1, column=7, padx=10, pady=5, sticky=W)
                Label(self.manager_details_label, text=manager_data[14], font=('arial', 12), bg = 'white', fg='green').grid(row=2, column=7, padx=10, pady=5, sticky=W)
            else:
                messagebox.showerror('Error', 'Failed to fetch Manager details')

            conn.close()

        except mysql.connector.Error as err:
            messagebox.showerror('Database Error', f"Error: {str(err)}")

    # get data from mysql
    def fatch_employee_data(self):
        conn = mysql.connector.connect(
                    host='localhost',
                    username='root',
                    password='Rahul@2012',
                    database='employee_management_system'
                )
        my_cursor = conn.cursor()
        query = 'SELECT * FROM employee WHERE Manager_ID = %s'
        my_cursor.execute(query, (self.Manager_ID,))
        data=my_cursor.fetchall()
        if len(data)!=0:
            self.employee_table.delete(*self.employee_table.get_children())
            for i in data:
                self.employee_table.insert("", END, values=i)
            conn.commit()
        conn.close()

    # get data from mysql
    def fatch_application_data(self):
        conn = mysql.connector.connect(
                    host='localhost',
                    username='root',
                    password='Rahul@2012',
                    database='employee_management_system'
                )
        my_cursor = conn.cursor()
        # Query to join employee and leave_applications based on Emp_ID and filter by Manager_ID
        query = '''
            SELECT leave_applications.*
            FROM leave_applications
            JOIN employee ON leave_applications.Emp_ID = employee.Emp_ID
            WHERE employee.Manager_ID = %s
        '''
        my_cursor.execute(query, (self.Manager_ID,))

        data = my_cursor.fetchall()

        if len(data) != 0:
            # Clear existing entries in the table
            self.application_table.delete(*self.application_table.get_children())

            # Insert the fetched leave application data into the table
            for i in data:
                self.application_table.insert("", END, values=i)

            conn.commit()

        conn.close()


    # Function to approve the selected leave application
# Approve application
    def approve_application(self):
        selected_item = self.application_table.focus()  # Get selected item
        if selected_item:
            application_data = self.application_table.item(selected_item)['values']
            status = application_data[6]  # Status column is at index 6
            if status == "Pending":
                application_id = application_data[0]# Get Application_ID from the row
            
                # Update the status in the database
                try:
                    approve = messagebox.askyesno('Approve','Are you sure you want to approve this application?')
                    if approve:
                        conn = mysql.connector.connect(
                        host='localhost',
                        username='root',
                        password='Rahul@2012',
                        database='employee_management_system'
                        )
                        my_cursor = conn.cursor()
                        query = "UPDATE leave_applications SET Status = 'Approved' WHERE Application_ID = %s"
                        my_cursor.execute(query, (application_id,))
                        conn.commit()
                        conn.close()
                        # Notify the user (optional)
                        messagebox.showinfo('Success', f"Application_ID: {application_id} approved successfully.")
                        # Refresh the data in the application table
                        self.fatch_application_data()

                    else:
                        if not approve:
                            return   
                        

                except Exception as e:
                    messagebox.showerror('Error',f"Error approving Application_ID {application_id}: {e}")
            else:
                messagebox.showerror('Error', "Only 'Pending' applications can be approved")

    
# Reject application
    def reject_application(self):
        selected_item = self.application_table.focus()  # Get selected item
        if selected_item:
            application_data = self.application_table.item(selected_item)['values']
            status = application_data[6]  # Status column is at index 6
            if status == "Pending":
                application_id = application_data[0]# Get Application_ID from the row
            
                # Update the status in the database
                try:
                    reject = messagebox.askyesno('Reject','Are you sure you want to reject this application?')
                    if reject:
                        conn = mysql.connector.connect(
                        host='localhost',
                        username='root',
                        password='Rahul@2012',
                        database='employee_management_system'
                        )
                        my_cursor = conn.cursor()
                        # SQL query to update the status to 'Rejected'
                        query = "UPDATE leave_applications SET Status = 'Rejected' WHERE Application_ID = %s"
                        my_cursor.execute(query, (application_id,))
                        conn.commit()
                        conn.close()
                        # Notify the user (optional)
                        messagebox.showinfo('Reject',f"Application_ID {application_id} rejected successfully.")
                        # Refresh the data in the application table
                        self.fatch_application_data()

                    else:
                        if not reject:
                            return
                except Exception as e:
                    messagebox.showerror('Error',f"Error rejecting Application_ID {application_id}: {e}")
            else:
                messagebox.showerror('Error', "Only 'Pending' applications can be rejected")

    def logout(self):
        self.root.destroy()  # Close the signup window
        self.manager_window.deiconify()  # Show the login window again
            




# Window
if __name__ == "__main__":
    root = Tk()  # Correct initialization of Tk
    app = ManagerDashboard(root)
    root.mainloop()