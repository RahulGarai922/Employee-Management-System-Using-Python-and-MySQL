from tkinter import *  # Import all necessary classes and constants from tkinter
from tkinter import ttk
from tkinter import messagebox # Import messagebox for showing dialogs
import mysql.connector # Import MySQL connector to interact with the database
from tkcalendar import DateEntry  #add calander in the entry feild of DOJ and DOB

class EmployeeDashboard:
    def __init__(self, root, Emp_ID,employee_window):
        self.employee_window = employee_window
        # Initialize the main application window
        self.root = root
        self.root.title("Employee Dashboard") # Set the window title
        self.root.geometry("1530x790+0+0")  # Set window dimensions
        self.Emp_ID = Emp_ID  # Store employee ID to fetch details later

        #Create and place a title label at the top of the window
        lbl_title =Label(self.root,text='EMPLOYEE DASHBOARD',font=('times new roman',37,'bold'),fg='darkblue',bg='white')
        lbl_title.place(x=0,y=0,width=1530,height=50)


        # Create and place the main frame
        main_frame = Frame(self.root,bd=3,relief=RIDGE,bg='white')
        main_frame.place(x=10,y=51,width=1505,height=730)

        # Create and place the upper frame within the main frame to hold employee info
        upper_frame = LabelFrame(main_frame,bd=2,relief=RIDGE,bg='white',text='Employee Information',font=('times new roman',10,'bold'),fg='red')
        upper_frame.place(x=10,y=10,width=1480,height=270)

        # Label for displaying employee details
        self.employee_details_label = Label(upper_frame, text='', font=('arial', 12, 'bold'), fg='blue', bg='white')
        self.employee_details_label.pack(pady=10)

        # Fetch and display employee details
        self.fetch_employee_details()

        # Leave Application Section
        leave_frame = LabelFrame(main_frame, bd=2, relief=RIDGE, bg='white', text='Apply for Leave', font=('times new roman', 10, 'bold'), fg='magenta')
        leave_frame.place(x=10, y=280, width=650, height=430)

        # Create and place widgets for applying leave
        lbl_leave_type = Label(leave_frame, text='Leave Type:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_leave_type.grid(row=0, column=0, padx=10, pady=10, sticky=W)

        # Dropdown for selecting leave type
        self.leave_type = ttk.Combobox(leave_frame, values=['Sick Leave', 'Casual Leave', 'Annual Leave'], font=('arial', 12), state='readonly')
        self.leave_type.grid(row=0, column=1, padx=10, pady=10)

        # Start date label and DateEntry (calendar widget)
        lbl_start_date = Label(leave_frame, text='Start Date (YYYY-MM-DD):', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_start_date.grid(row=1, column=0, padx=10, pady=10, sticky=W)
        self.start_date = DateEntry(leave_frame, font=('arial', 12),date_pattern='yyyy-mm-dd')
        self.start_date.grid(row=1, column=1, padx=10, pady=10)

        # End date label and DateEntry
        lbl_end_date = Label(leave_frame, text='End Date (YYYY-MM-DD):', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_end_date.grid(row=2, column=0, padx=10, pady=10, sticky=W)

        self.end_date = DateEntry(leave_frame, font=('arial', 12),date_pattern='yyyy-mm-dd')
        self.end_date.grid(row=2, column=1, padx=10, pady=10)

        # Reason for leave entry field
        lbl_reason = Label(leave_frame, text='Reason for Leave:', font=('arial', 12, 'bold'), fg='blue', bg='white')
        lbl_reason.grid(row=3, column=0, padx=10, pady=10, sticky=W)

        self.reason = Entry(leave_frame, font=('arial', 12), width=40)
        self.reason.grid(row=3, column=1, padx=10, pady=10)

        # Button to apply for leave
        btn_apply_leave = Button(leave_frame, text='Apply Leave', command=self.apply_leave, font=('arial', 12, 'bold'), bg='green', fg='white')
        btn_apply_leave.grid(row=4, column=0, columnspan=2, padx=10, pady=20)

        # Create and place the table frame for displaying leave history
        table_frame=LabelFrame(main_frame,bd = 3,relief=RIDGE,  bg='white', text='Application History', font=('times new roman', 10, 'bold'), fg='magenta') 
        table_frame.place(x = 670 , y = 285, width=800,height=430)

        # Create and place scrollbars for the table
        scroll_x = ttk.Scrollbar(table_frame, orient=HORIZONTAL) 
        scroll_y = ttk.Scrollbar(table_frame,orient=VERTICAL)
 
        # Create the employee table with defined columns and set the scroll commands
        self.employee_table=ttk.Treeview(table_frame,column=("Application_ID","Emp_ID","LeaveType","StartDate","EndDate","Reason","Status"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        # Pack scrollbars into the table frame
        scroll_x.pack(side=BOTTOM, fill=X) 
        scroll_y.pack(side=RIGHT, fill=Y)

        # Configure scrollbars to work with the employee table
        scroll_x.config(command=self.employee_table.xview)
        scroll_y.config(command=self.employee_table.yview)

        # Define the column headers for the employee table
        self.employee_table.heading('Application_ID',text='Application_ID')
        self.employee_table.heading('Emp_ID',text='Emp_ID')
        self.employee_table.heading('LeaveType',text='LeaveType')
        self.employee_table.heading('StartDate',text='StartDate')
        self.employee_table.heading('EndDate',text='EndDate')
        self.employee_table.heading('Reason',text='Reason')
        self.employee_table.heading('Status',text='Status')

        # Set the table to display only the defined headings
        self.employee_table['show']='headings'

        # Define the width of each column
        self.employee_table.column("Application_ID", width=100)
        self.employee_table.column("Emp_ID", width=60)
        self.employee_table.column("LeaveType", width=80)
        self.employee_table.column("StartDate", width=80)
        self.employee_table.column("EndDate", width=80)
        self.employee_table.column("Reason", width=200)
        self.employee_table.column("Status", width=80)

        # Pack the table to fill both X and Y axes and expand within the frame
        self.employee_table.pack(fill=BOTH, expand=1)
        self.fatch_data() # Fetch data for the table

        # Login button to trigger the logout action
        btn_logout = Button(self.root, text='Log Out', command=self.logout, font=('arial', 12, 'bold'), bg='red', fg='white', cursor='hand2')
        btn_logout.place(x=1350, y=10, width=100, height=30)
      
      #----------------------function declearation--------------------------
              
    # Fetch employee details from the database
    def fetch_employee_details(self):
        try:
            # Connect to MySQL database
            conn = mysql.connector.connect(
                host='localhost',
                username='root',
                password='Rahul@2012',
                database='employee_management_system'
            )
            my_cursor = conn.cursor()

            # Fetch employee details based on employee_id
            query = 'SELECT * FROM employee WHERE Emp_ID = %s'
            my_cursor.execute(query, (self.Emp_ID,))
            employee_data = my_cursor.fetchone()

            # If employee data exists, display it in the label grid
            if employee_data:
                # Create and place labels and entries in the required layout using grid
                labels = [
                    ("Employee ID:", 0, 0), ("Manager ID:", 1, 0), ("Department:", 2, 0), ("Designation:", 3, 0), ("Email:", 4, 0),
                    ("Name:", 0, 2), ("Mobile_Number:", 1, 2), ("D.O.J:", 2, 2), ("Country:", 3, 2), ("City:", 4, 2), 
                    ("Married Status:", 0, 4), ("D.O.B:", 1, 4), ("ID Type:", 2, 4), ("ID Proof:", 3, 4), ("Gender:", 4, 4), 
                    ("Salary:", 0, 6) ,("Password:", 1, 6)
                ]

                # Create labels and text boxes for displaying employee details
                for label_text, row, col in labels:
                    Label(self.employee_details_label, text=label_text, font=('arial', 12, 'bold'), fg='red', bg='white').grid(row=row, column=col, padx=10, pady=5, sticky=W)

                # Display data in corresponding positions
                Label(self.employee_details_label, text=employee_data[0], font=('arial', 12), bg = 'white', fg='green').grid(row=0, column=1, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[1], font=('arial', 12), bg = 'white', fg='green').grid(row=1, column=1, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[2], font=('arial', 12), bg = 'white', fg='green').grid(row=2, column=1, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[3], font=('arial', 12), bg = 'white', fg='green').grid(row=3, column=1, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[7], font=('arial', 12), bg = 'white', fg='green').grid(row=4, column=1, padx=10, pady=5, sticky=W)

                Label(self.employee_details_label, text=employee_data[4], font=('arial', 12), bg = 'white', fg='green').grid(row=0, column=3, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[5], font=('arial', 12), bg = 'white', fg='green').grid(row=1, column=3, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[6], font=('arial', 12), bg = 'white', fg='green').grid(row=2, column=3, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[8], font=('arial', 12), bg = 'white', fg='green').grid(row=3, column=3, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[9], font=('arial', 12), bg = 'white', fg='green').grid(row=4, column=3, padx=10, pady=5, sticky=W)

                Label(self.employee_details_label, text=employee_data[10], font=('arial', 12), bg = 'white', fg='green').grid(row=0, column=5, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[11], font=('arial', 12), bg = 'white', fg='green').grid(row=1, column=5, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[12], font=('arial', 12), bg = 'white', fg='green').grid(row=2, column=5, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[13], font=('arial', 12), bg = 'white', fg='green').grid(row=3, column=5, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[14], font=('arial', 12), bg = 'white', fg='green').grid(row=4, column=5, padx=10, pady=5, sticky=W)

                Label(self.employee_details_label, text=employee_data[15], font=('arial', 12), bg = 'white', fg='green').grid(row=0, column=7, padx=10, pady=5, sticky=W)
                Label(self.employee_details_label, text=employee_data[16], font=('arial', 12), bg = 'white', fg='green').grid(row=1, column=7, padx=10, pady=5, sticky=W)
            else:
                messagebox.showerror('Error', 'Failed to fetch employee details')

            conn.close()

        except mysql.connector.Error as err:
            messagebox.showerror('Database Error', f"Error: {str(err)}")

    def apply_leave(self):
        # Get the input from the fields
        leave_type = self.leave_type.get()
        start_date = self.start_date.get()
        end_date = self.end_date.get()
        reason = self.reason.get()

        # Validate input
        if not leave_type or not start_date or not end_date or not reason:
            messagebox.showerror('Error', 'All fields are required')
            return

        try:
            # Connect to MySQL database
            conn = mysql.connector.connect(
                host='localhost',
                username='root',
                password='Rahul@2012',
                database='employee_management_system'
            )
            my_cursor = conn.cursor()

            # Insert leave application into the database
            query = 'INSERT INTO leave_applications (Emp_ID, LeaveType, StartDate, EndDate, Reason) VALUES (%s, %s, %s, %s, %s)'
            values = (self.Emp_ID, leave_type, start_date, end_date, reason)
            my_cursor.execute(query, values)
            conn.commit()

            messagebox.showinfo('Success', 'Leave application submitted successfully')
            self.fatch_data()
            conn.close()
        except mysql.connector.Error as err:
            messagebox.showerror('Database Error', f"Error: {str(err)}")


    # get data from mysql
    def fatch_data(self):
        conn = mysql.connector.connect(
                    host='localhost',
                    username='root',
                    password='Rahul@2012',
                    database='employee_management_system'
                )
        my_cursor = conn.cursor()
        query = 'SELECT * FROM leave_applications WHERE Emp_ID = %s'
        my_cursor.execute(query, (self.Emp_ID,))
        data=my_cursor.fetchall()
        if len(data)!=0:
            self.employee_table.delete(*self.employee_table.get_children())
            for i in data:
                self.employee_table.insert("", END, values=i)
            conn.commit()
        conn.close()

    def logout(self):
        self.root.destroy()  # Close the signup window
        self.employee_window.deiconify()  # Show the login window again

# Window
if __name__ == "__main__":
    root = Tk()  # Correct initialization of Tk
    app = EmployeeDashboard(root)
    root.mainloop()
