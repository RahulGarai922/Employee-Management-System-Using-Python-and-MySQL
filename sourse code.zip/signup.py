from tkinter import*       ## Import all classes and functions from tkinter
from tkinter import ttk
from tkinter import messagebox  # Import messagebox for displaying alerts
import mysql.connector # Import MySQL connector for database interaction

class SignupPage():
    
    def __init__(self,root,signup_window):
        self.signup_window = signup_window
        self.root = root      # Assign the root window to an instance variable
        self.root.geometry('1530x800+0+0')  ## Set the size and position of the window
        self.root.title('Employee Management System') ## Set the title of the window
        

        # Create the main frame to hold signup form elements
        main_frame = Frame(self.root,bd=3,relief=RIDGE,bg='lightyellow')
        main_frame.place(x=365,y=100,width=680,height=550)

        # Create and place the 'SIGNUP' label at the top
        lbl_signup = Label(main_frame, text='SIGNUP', font=('arial', 20, 'bold'), fg='green', bg='lightyellow')
        lbl_signup.place(x=275,y=20)

        # First Name Label
        lbl_firstname = Label(main_frame, text='First Name:', font=('arial', 14, 'bold'), fg='black', bg='lightyellow')
        lbl_firstname.place(x=50,y=100)

        # First Name Entry
        self.firstneme_entry = ttk.Entry(main_frame,font=('arial', 14))
        self.firstneme_entry.place(x=50,y=130,width=250)

        # Create and place the label for the LAST NAME
        lbl_lastname = Label(main_frame, text='Last Name:', font=('arial', 14, 'bold'), fg='black', bg='lightyellow')
        lbl_lastname.place(x=370,y=100)

        #Create and place the entry field for the latname
        self.lastname_entry = ttk.Entry(main_frame,font=('arial', 14))
        self.lastname_entry.place(x=370,y=130,width=250)

        # Create and place the label for the contact
        lbl_contact = Label(main_frame, text='Contact No:', font=('arial', 14, 'bold'), fg='black', bg='lightyellow')
        lbl_contact.place(x=50,y=170)

        #Create and place the entry field for the contact
        self.contact_entry = ttk.Entry(main_frame,font=('arial', 14))
        self.contact_entry.place(x=50,y=200,width=250)

        # Create and place the label for the email
        lbl_email = Label(main_frame, text='Email:', font=('arial', 14, 'bold'), fg='black', bg='lightyellow')
        lbl_email.place(x=370,y=170)

        #Create and place the entry field for th email
        self.email_entry = ttk.Entry(main_frame,font=('arial', 14))
        self.email_entry.place(x=370,y=200,width=250)

        # Create and place the label for the ID Type
        lbl_id_type = Label(main_frame, text='Select ID Type:', font=('arial', 14, 'bold'), fg='black', bg='lightyellow')
        lbl_id_type.place(x=50,y=240)

        # Create and place the dropdown list for selecting ID Type
        self.id_type = ttk.Combobox(main_frame, font=('arial', 14, 'bold'),state='readonly')
        self.id_type['value'] = ('Select ID Proof','Votar Card','Adhar Card','PAN card','Driving License')
        self.id_type.place(x=50,y=270,width=250)

         # Create and place the label for the ID Proof Number
        lbl_id_proof = Label(main_frame, text='ID Number:', font=('arial', 14, 'bold'), fg='black', bg='lightyellow')
        lbl_id_proof.place(x=370,y=240)

        #Create and place the entry field for ID Proof Number
        self.id_number = ttk.Entry(main_frame,font=('arial', 14))
        self.id_number.place(x=370,y=270,width=250)

        # Create and place the label for the password
        lbl_password = Label(main_frame, text='Password:', font=('arial', 14, 'bold'), fg='black', bg='lightyellow')
        lbl_password.place(x=50,y=310)

        #Create and place the entry field for ths password
        self.password_entry = ttk.Entry(main_frame,font=('arial', 14),show='*')
        self.password_entry.place(x=50,y=340,width=250)

        # Show Password Checkbox
        show_password = Checkbutton(main_frame, command=self.show_password, text='Show Password',bg='lightyellow')
        show_password.place(x=370,y=375)

        # Create and place the label for the confirm password
        lbl_confirm_password = Label(main_frame, text='Confirm Password:', font=('arial', 14, 'bold'), fg='black', bg='lightyellow')
        lbl_confirm_password.place(x=370,y=310)

        #Create and place the entry field for the confirm password
        self.confirm_password = ttk.Entry(main_frame,font=('arial', 14),show='*')
        self.confirm_password.place(x=370,y=340,width=250)

        # Terms and Conditions checkbox to agree before registering
        self.terms_var = IntVar()  # Variable to track checkbox state
        self.checkbtn = Checkbutton(main_frame,text="I Agree the Terms & Conditions", variable=self.terms_var, command=self.toggle_register_button,font=('arial', 12, 'bold'),fg='blue', bg='lightyellow',onvalue=1,offvalue=0)
        self.checkbtn.place(x=50,y=380)

        # Register button, initially disabled
        self.btn_register = Button(main_frame,text='Register Now',command=self.add_data,font=('arial', 14, 'bold'),bg='lightpink',fg='blue',borderwidth=0,activeforeground='blue',activebackground='lightpink',cursor='hand2')
        self.btn_register.place(x=190,y=450,width=300)
        self.btn_register.config(state=DISABLED)  # Register button, initially disabled

        # Login button to trigger the login action
        btn_login = Button(main_frame, text='LOGIN', command=self.return_login_page, font=('arial', 12, 'bold'), bg='lightyellow', fg='blue', bd=0, cursor='hand2')
        btn_login.place(x=290, y=500, width=100, height=30)

    def toggle_register_button(self):
        """Enable or disable the Register button based on checkbox state."""
        if self.terms_var.get() == 1:    # If checkbox is selected
            self.btn_register.config(state=NORMAL)  # Enable the button
        else:
            self.btn_register.config(state=DISABLED)  # Disable the button

    def add_data(self):
    # Check if any of the required fields are empty
      if self.firstneme_entry.get() == '' or self.lastname_entry.get() == '' or self.contact_entry.get() == '' or self.email_entry.get() == '' or self.id_type.get() == '' or self.id_number.get() == '' or self.password_entry.get() == '' or self.confirm_password.get() == '':
          messagebox.showerror('Error', 'All Fields are required') # Show error if fields are empty
      else:
          # Check if passwords match
          if self.password_entry.get() != self.confirm_password.get():
              messagebox.showerror('Error', 'Passwords do not match')
              return  # Stop execution if passwords do not match to prevent data insertion
          try:
              # Establish a connection to the MySQL database
              conn = mysql.connector.connect(
                  host='localhost',
                  username='root',
                  password='Rahul@2012',
                  database='employee_management_system'
              )
              my_cursor = conn.cursor()
            
              # Insert the data into the admin table
              my_cursor.execute('INSERT INTO admin (First_Name, Last_Name, Contact_No, Email, ID_Type, ID_Proof, Password) VALUES (%s, %s, %s, %s, %s, %s, %s)', (
                  self.firstneme_entry.get(),
                  self.lastname_entry.get(),
                  self.contact_entry.get(),
                  self.email_entry.get(),
                  self.id_type.get(),
                  self.id_number.get(),
                  self.password_entry.get(),
              ))

              conn.commit()  # Commit the transaction to save changes
              conn.close()  # Close the connection
              messagebox.showinfo('Success', 'Employee has been added!', parent=self.root) # Show success message
          except Exception as es:
              messagebox.showerror('Error', f'Due to {str(es)}', parent=self.root) # Show error if there's an issue

    def show_password(self):
        if self.password_entry.cget('show') == '*' or self.confirm_password.cget('show') == '*':
            self.password_entry.config(show='') or self.confirm_password.config(show='')
        else:
            self.password_entry.config(show='*') or self.confirm_password.config(show='*')

    def return_login_page(self):
        self.root.destroy()  # Close the signup window
        self.signup_window.deiconify()  # Show the login window again
    
        
    
    

    









# Main Application Entry Point
if __name__ == "__main__":
    root = Tk()
    app = SignupPage(root)
    root.mainloop()